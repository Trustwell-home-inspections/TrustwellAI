import React from 'react';

function App() {
  return (
    <div style={{ padding: '2rem', fontFamily: 'Arial' }}>
      <h1>Trustwell AI MVP</h1>
      <p>This is your starter React app. You can now build your thermal + lead inspection interface here.</p>
    </div>
  );
}

export default App;
